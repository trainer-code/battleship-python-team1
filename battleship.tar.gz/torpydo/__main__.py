"""
Entry point for when the game is run as `python -m torpydo`.
"""
from torpydo.battleship import main

main()
